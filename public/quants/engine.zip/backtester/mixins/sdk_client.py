"""
SDKClientMixin — API authentication, data fetching, server-side calcs
=====================================================================

Extracted from core.py to keep the Backtester class focused on the
strategy pipeline (data → signals → weights → positions → performance).

All methods expect the host class to have the attributes set by
Backtester.__init__ (api_url, _email, _password, _api_key, _sdk_client,
_source, _granularity, backtest_period, instruments, etc.).

Copyright (c) 2026 QuantJourney.
Licensed under the Apache License 2.0.
"""

from __future__ import annotations

import logging
import os
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import pandas as pd

    from backtester.core import BacktestPeriod
    from backtester.execution.contract_spec import ContractSpec
    from backtester.sdk.client import AsyncAPIClient

try:
    from backtester.utils.logger import logger
except Exception:
    logger = logging.getLogger("backtester")


class SDKClientMixin:
    """API authentication, market-data fetching, and server-side calculations."""

    _local_data_metadata: dict[str, Any] | None
    _data_csv: str | None
    _local_data_input: str | os.PathLike[str] | pd.DataFrame | None
    _sdk_client: AsyncAPIClient | None
    _csv_config: bool
    _granularity: str
    base_currency: str
    backtest_period: BacktestPeriod
    instruments: list[str]

    if TYPE_CHECKING:

        def _contract_spec(self, instrument: str) -> ContractSpec: ...

    @staticmethod
    def _replace_existing_session_enabled() -> bool:
        value = os.getenv("QJ_REPLACE_EXISTING_SESSION", "1").strip().lower()
        return value not in {"0", "false", "no", "off"}

    @staticmethod
    def _response_detail(resp: Any) -> Any:
        try:
            body = resp.json()
        except Exception:
            return getattr(resp, "text", "")
        if isinstance(body, dict):
            return body.get("detail") or body
        return body

    @classmethod
    def _is_active_session_conflict(cls, resp: Any) -> bool:
        if getattr(resp, "status_code", None) != 409:
            return False
        detail = cls._response_detail(resp)
        return isinstance(detail, dict) and detail.get("code") == "active_session_exists"

    @staticmethod
    def _quota_limit_message(exc: Exception) -> str | None:
        body = getattr(exc, "response_body", None)
        body = body if isinstance(body, dict) else {}
        code = (
            getattr(exc, "error_code", None)
            or body.get("error_code")
            or body.get("code")
            or body.get("type")
        )
        status = getattr(exc, "status_code", None) or body.get("status")
        detail = str(body.get("detail") or exc)
        text = f"{code or ''} {status or ''} {detail}".lower()
        if code != "ERR_RATE_002" and status != 429 and "quota" not in text:
            return None

        yellow = "\033[33m"
        reset = "\033[0m"
        upgrade_url = "https://backtester.quantjourney.cloud"
        return (
            f"{yellow}QuantJourney Backtester limit reached.\n"
            f"  {detail}\n"
            "  Upgrade to QuantJourney Pro to continue or ask "
            "support@quantjourney.cloud to increase your limit.\n"
            f"  Pro: {upgrade_url}{reset}"
        )

    @classmethod
    def _raise_quota_limit_error(cls, exc: Exception) -> None:
        message = cls._quota_limit_message(exc)
        if not message:
            raise exc
        quota_exc = RuntimeError("QuantJourney Backtester quota exceeded")
        quota_exc._qj_quota_message = message
        raise quota_exc from exc

    @classmethod
    def _raise_prepare_api_error(cls, exc: Exception) -> None:
        """Preserve quota behavior and expose structured prepare validation."""

        message = cls._quota_limit_message(exc)
        if message:
            cls._raise_quota_limit_error(exc)

        from backtester.sdk.client import BacktesterAccessError, PrepareValidationError

        access_error = BacktesterAccessError.from_api_error(exc)
        if access_error is not None:
            raise access_error from exc

        validation_error = PrepareValidationError.from_api_error(exc)
        if validation_error is not None:
            raise validation_error from exc
        raise exc

    # ─────────────────────────────────────────────────────────────────
    # SDK Client — uses quantjourney.sdk.client.AsyncAPIClient
    # ─────────────────────────────────────────────────────────────────

    async def _get_sdk_client(self) -> AsyncAPIClient:
        """Lazy-initialize and return the SDK async client."""
        if self._sdk_client is not None:
            return self._sdk_client

        from backtester.sdk.client import AsyncAPIClient, MissingCredentialsError

        if self._api_key:
            # API key auth — handled by SDK (Bearer header)
            self._sdk_client = AsyncAPIClient(
                base_url=self.api_url,
                api_key=self._api_key,
                auth_url=os.getenv("QJ_AUTH_URL") or "https://auth.quantjourney.cloud",
                read_timeout=120.0,
            )
            logger.info("[Backtester] Using API key auth via SDK")
        elif self._email and self._password:
            auth_url = (os.getenv("QJ_AUTH_URL") or "https://auth.quantjourney.cloud").rstrip("/")
            # Email/password — login and set tokens
            self._sdk_client = AsyncAPIClient(
                base_url=self.api_url,
                auth_url=auth_url,
                read_timeout=120.0,
            )
            # Login to get JWT
            login_payload = {
                "email": self._email,
                "password": self._password,
                "service": os.getenv("QJ_AUTH_SERVICE", "backtester"),
            }
            resp = await self._sdk_client.client.post(
                f"{auth_url}/auth/login",
                json=login_payload,
            )
            if self._is_active_session_conflict(resp):
                if not self._replace_existing_session_enabled():
                    raise ValueError(
                        "Authentication blocked by an active QuantJourney session at "
                        f"{auth_url}/auth/login\n"
                        f"  Email: {self._email}\n"
                        "  Set QJ_REPLACE_EXISTING_SESSION=1 to let the CLI replace "
                        "the existing session,\n"
                        "  or use QJ_API_KEY to avoid browser-session conflicts."
                    )
                logger.info(
                    "[Backtester] Active auth session exists; replacing it for this "
                    "headless backtester run"
                )
                resp = await self._sdk_client.client.post(
                    f"{auth_url}/auth/login",
                    json={**login_payload, "replace_existing_session": True},
                )
            if resp.status_code == 401:
                raise ValueError(
                    f"Authentication failed (401 Unauthorized) at {auth_url}/auth/login\n"
                    f"  Email: {self._email}\n"
                    f"  Please check your QJ_EMAIL / QJ_PASSWORD environment variables,\n"
                    f"  or set QJ_API_KEY for API key authentication.\n"
                    f"  Hint: export QJ_API_KEY='your-key-here' or add it to .env"
                )
            if resp.status_code == 409:
                raise ValueError(
                    f"Authentication failed (409 Conflict) at {auth_url}/auth/login\n"
                    f"  Email: {self._email}\n"
                    f"  Detail: {self._response_detail(resp)}\n"
                    f"  Try QJ_REPLACE_EXISTING_SESSION=1 or use QJ_API_KEY."
                )
            if resp.status_code == 403:
                raise ValueError(
                    f"Authentication failed (403 Forbidden) at {auth_url}/auth/login\n"
                    f"  Email: {self._email}\n"
                    f"  Detail: {self._response_detail(resp)}"
                )
            resp.raise_for_status()
            data = resp.json()
            access = data["access_token"]
            refresh = data.get("refresh_token")
            self._sdk_client.set_bearer_tokens(access, refresh)
            expires = data.get("expires_in", "?")
            logger.info(f"[Backtester] Logged in as {self._email} (expires in {expires}s)")
        else:
            raise MissingCredentialsError()

        return self._sdk_client

    # ─────────────────────────────────────────────────────────────────
    # Data Fetching — POST /bt/prepare (via SDK)
    # ─────────────────────────────────────────────────────────────────

    async def _fetch_market_data(self) -> None:
        """
        Fetch market data from /bt/prepare API via the SDK client.
        Auto token refresh on 401 is handled by the SDK.
        """
        local_input = getattr(self, "_local_data_input", None)
        if local_input is not None:
            from backtester.local_data import load_csv_data, load_local_data

            if self._granularity != "1d":
                raise ValueError("Local data supports daily equity data only")
            if self.base_currency != "USD":
                raise ValueError("Local data currently supports USD equities only")
            selection = {
                "instruments": None if self._csv_config else self.instruments,
                "start": None if self._csv_config else self.backtest_period.start,
                "end": None if self._csv_config else self.backtest_period.end,
            }
            if self._data_csv is not None:
                data = load_csv_data(self._data_csv, **selection)
            else:
                data = load_local_data(local_input, **selection)
            for symbol in data["instrument_names"]:
                if self._contract_spec(symbol).asset_class.value != "equity":
                    raise ValueError("Local data requires equity instrument specifications")
            if self._csv_config:
                self.instruments = data["instrument_names"]
                self.backtest_period = type(self.backtest_period)(
                    start=data["summary"]["start"], end=data["summary"]["end"]
                )
            self._api_response = data
            self._source = data["summary"]["source"]
            self._local_data_metadata = {**data["local_data"], "csv_config": self._csv_config}
            self.session_id = None
            self.dataset_id = None
            self._validate_data_completeness_response()
            return

        if self._source == "sample" or os.getenv("QJ_SAMPLE_DATA", "").strip().lower() in {
            "1",
            "true",
            "yes",
            "on",
        }:
            from backtester.sample_data import build_sample_bt_payload

            self._api_response = build_sample_bt_payload(
                instruments=self.instruments,
                start=self.backtest_period.start,
                end=self.backtest_period.end,
                initial_nav=100.0,
            )
            self.session_id = self._api_response["session_id"]
            self.dataset_id = self._api_response["dataset_id"]
            self._validate_data_completeness_response()
            summary = self._api_response["summary"]
            logger.info(
                f"[Backtester] Sample data loaded: "
                f"session={self.session_id}, dataset={self.dataset_id}, "
                f"instruments={summary.get('instruments')}, dates={summary.get('dates')}"
            )
            return

        client = await self._get_sdk_client()

        payload = {
            "provider": {
                "source": self._source,
                "granularity": self._granularity,
            },
            "backtest_period": {
                "start": self.backtest_period.start,
                "end": self.backtest_period.end,
            },
            "instruments": self.instruments,
            "persist": self._persist,
            "dedupe": self._dedupe,
            "force_refresh": self._force_refresh,
        }

        logger.info(
            f"[Backtester] POST /bt/prepare: {len(self.instruments)} instruments, "
            f"{self.backtest_period.start}..{self.backtest_period.end}, "
            f"source={self._source}, granularity={self._granularity}"
        )

        try:
            self._api_response = await client._request("/bt/prepare", payload)
        except Exception as exc:
            self._raise_prepare_api_error(exc)

        self.session_id = self._api_response.get("session_id")
        self.dataset_id = self._api_response.get("dataset_id")
        self._validate_data_completeness_response()
        summary = self._api_response.get("summary", {})

        logger.info(
            f"[Backtester] Data received: "
            f"session={self.session_id}, dataset={self.dataset_id}, "
            f"instruments={summary.get('instruments')}, dates={summary.get('dates')}, "
            f"granularity={self._granularity}"
        )

    def _validate_data_completeness_response(self) -> None:
        """Fail closed when the provider declares or reveals a partial universe."""
        response = self._api_response if isinstance(self._api_response, dict) else {}
        summary = response.get("summary", {})
        if not isinstance(summary, dict):
            summary = {}

        declared_missing = response.get(
            "missing_instruments", summary.get("missing_instruments", [])
        )
        if isinstance(declared_missing, str):
            declared_missing = [declared_missing]
        declared_missing = {str(symbol).strip().upper() for symbol in (declared_missing or [])}

        received_raw = response.get("instrument_names")
        received = (
            {str(symbol).strip().upper() for symbol in received_raw}
            if isinstance(received_raw, (list, tuple, set))
            else set()
        )
        requested = {str(symbol).strip().upper() for symbol in self.instruments}
        inferred_missing = requested - received if received else set()
        missing = sorted(declared_missing | inferred_missing)
        partial = bool(response.get("partial", summary.get("partial", False)))
        if not missing and not partial:
            return

        detail = f"missing={missing}" if missing else "provider marked response partial"
        message = f"Incomplete market-data response ({detail})"
        if not getattr(self, "_allow_partial_data", False):
            raise ValueError(message + ". Pass allow_partial_data=True to opt in.")
        logger.warning(f"[Backtester] {message}; continuing by explicit opt-in")

    # ─────────────────────────────────────────────────────────────────
    # Server-Side Calculations (optional convenience)
    # ─────────────────────────────────────────────────────────────────

    async def calc_portfolio_server(
        self,
        calc_ids: list[str],
        params: dict[str, dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """
        Run calculations on the server via POST /bt/calc/portfolio.
        Returns the raw results dict.
        """
        if not self.session_id:
            raise ValueError("No session_id — run prepare first")

        client = await self._get_sdk_client()

        result = await client._request(
            "/bt/calc/portfolio",
            {
                "session_id": self.session_id,
                "calc_ids": calc_ids,
                "params": params or {},
            },
        )
        return result.get("results", {}) if isinstance(result, dict) else result

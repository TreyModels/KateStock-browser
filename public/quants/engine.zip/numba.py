def njit(*args, **kwargs):
 if args and callable(args[0]): return args[0]
 return lambda f:f
prange=range
